<?php
// El contenido HTML de esta página se edita en el archivo del mismo nombre.
readfile(__DIR__ . '/index.html');
