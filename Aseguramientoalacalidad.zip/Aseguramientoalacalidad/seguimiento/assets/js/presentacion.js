/* Imágenes legibles a tamaño completo y navegación accesible. */
document.addEventListener('DOMContentLoaded', function () {
  const dialog = document.getElementById('sgImageDialog');
  const full = document.getElementById('sgImageFull');
  const caption = document.getElementById('sgImageCaption');
  let previousFocus;
  if (dialog && typeof dialog.showModal === 'function') {
    document.querySelectorAll('.seguimiento-module .stat-grid img, .seguimiento-module .img-frame img, .seguimiento-module .job-card img.thumb').forEach(function (img) {
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'sg-image-trigger';
      button.setAttribute('aria-label', 'Ampliar imagen: ' + (img.alt || 'Información institucional'));
      img.parentNode.insertBefore(button, img); button.appendChild(img);
      button.addEventListener('click', function () {
        previousFocus = button; full.src = img.currentSrc || img.src; full.alt = img.alt;
        caption.textContent = img.alt; dialog.showModal();
      });
    });
    dialog.querySelector('.sg-dialog-close').addEventListener('click', function () { dialog.close(); });
    dialog.addEventListener('click', function (event) {
      if (event.target === dialog) {
        const box = dialog.getBoundingClientRect();
        if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) dialog.close();
      }
    });
    dialog.addEventListener('close', function () { if (previousFocus) previousFocus.focus(); });
  }
});
