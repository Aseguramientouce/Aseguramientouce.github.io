
  function showPage(id){
    var page = document.getElementById(id);
    if(!page || !page.classList.contains('page')) return;
    document.querySelectorAll('.seguimiento-module .page').forEach(function(p){ p.classList.remove('active'); });
    page.classList.add('active');
    document.getElementById('backBar').style.display = (id === 'inicio') ? 'none' : 'block';
    var heading = page.querySelector('h1');
    if(heading){ heading.setAttribute('tabindex','-1'); heading.focus({preventScroll:true}); }
    document.querySelectorAll('.seguimiento-module .dropdown button').forEach(function(button){button.blur();});
    window.scrollTo({top:0, behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth'});
    if(id === 'encuesta-graduados'){ actualizarContadorEncuesta(); }
  }

  /* ===== BASE DE DATOS DE LA ENCUESTA DE SEGUIMIENTO A GRADUADOS ===== */
  /* Los registros se guardan como datos compartidos (shared) bajo el prefijo
     "respuesta_encuesta_graduados:" para que la Facultad pueda consultar el
     total de participación. Cada envío crea una llave única. */

  async function actualizarContadorEncuesta(){
    var contador = document.getElementById('encuestaContador');
    if(!contador || !window.storage || !window.storage.list) {
      if(contador) contador.textContent = '';
      return;
    }
    try{
      var resultado = await window.storage.list('respuesta_encuesta_graduados:', true);
      var total = (resultado && resultado.keys) ? resultado.keys.length : 0;
      contador.textContent = 'Respuestas registradas hasta el momento: ' + total;
    }catch(err){
      contador.textContent = '';
      console.error('No se pudo leer el contador de respuestas:', err);
    }
  }

  document.addEventListener('DOMContentLoaded', function(){
    actualizarContadorEncuesta();

    var form = document.getElementById('formEncuestaGraduados');
    if(!form) return;

    form.addEventListener('submit', async function(evento){
      evento.preventDefault();
      var mensaje = document.getElementById('encuestaMensaje');
      var boton = document.getElementById('btnEnviarEncuesta');

      if(!form.checkValidity()){
        form.reportValidity();
        return;
      }

      boton.disabled = true;
      boton.textContent = 'Enviando…';
      mensaje.className = 'encuesta-mensaje';
      mensaje.textContent = '';

      var datos = Object.fromEntries(new FormData(form).entries());
      datos.fechaEnvio = new Date().toISOString();

      var llave = 'respuesta_encuesta_graduados:' + Date.now() + '_' + Math.random().toString(36).slice(2,8);

      try{
        if(!window.storage || !window.storage.set){
          throw new Error('Almacenamiento no disponible');
        }
        var guardado = await window.storage.set(llave, JSON.stringify(datos), true);
        if(!guardado){
          throw new Error('El guardado no devolvió confirmación');
        }
        mensaje.classList.add('ok');
        mensaje.textContent = '¡Gracias! Tus respuestas fueron registradas correctamente en la base de datos de Seguimiento a Graduados.';
        form.reset();
        actualizarContadorEncuesta();
      }catch(err){
        console.error('Error al guardar la encuesta:', err);
        mensaje.classList.add('error');
        mensaje.textContent = 'Ocurrió un problema al guardar tus respuestas. Por favor, inténtalo nuevamente en unos minutos.';
      }finally{
        boton.disabled = false;
        boton.textContent = 'Enviar mis respuestas';
      }
    });
  });
